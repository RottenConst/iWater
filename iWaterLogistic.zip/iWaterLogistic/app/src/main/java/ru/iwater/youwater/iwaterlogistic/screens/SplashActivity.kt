package ru.iwater.youwater.iwaterlogistic.screens

class SplashActivity {
}