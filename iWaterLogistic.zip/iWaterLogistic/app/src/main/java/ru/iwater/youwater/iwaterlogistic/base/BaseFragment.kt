package ru.iwater.youwater.iwaterlogistic.base

class BaseFragment {
}